"use client";
// import BlurText from "@/components/BlurText";
import Hero from "@/components/ui/Hero";
export default function Home() {
  const handleAnimationComplete = () => {
    console.log("Animation completed!");
  };

  return (
    <Hero />
  );
}
