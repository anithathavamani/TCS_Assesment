"use client"
import ChatPage from '@/components/ui/ChatPage'
import React from 'react'

const page = () => {
  return (
    <ChatPage/>
  )
}

export default page