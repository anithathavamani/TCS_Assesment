// src/components/ChatPage.tsx
import React, { useState } from "react";
import ChatMessage from "./ChatMessage";
import ChatInput from "./ChatInput";

const ChatPage: React.FC = () => {
  type Message = {
    id: number;
    sender: "user" | "bot";
    text: string;
  };

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      sender: "bot",
      text: "Hello! I'm CleverBotX. How can I help you today?",
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);

  // 🧩 Handle sending user message and fetching bot reply
  const handleSend = async (text: string) => {
    if (!text.trim()) return;

    const userMsg: Message = { id: Date.now(), sender: "user", text };
    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    // Create placeholder for streaming bot response
    const botId = Date.now() + 1;
    setMessages((prev) => [...prev, { id: botId, sender: "bot", text: "" }]);

    try {
      const response = await fetch(
        "http://localhost:1234/v1/chat/completions",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: "google/gemma-3n-e4b", // or your model name
            messages: [
              ...messages.map((m) => ({
                role: m.sender === "user" ? "user" : "system",
                content: "Your ai assistance",
              })),
              { role: "user", content: text },
            ],
            stream: true, // enable streaming
          }),
        }
      );

      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let botReply = "";

      // Read streaming chunks
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value);
        const lines = chunk.split("\n");

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const json = line.replace("data: ", "").trim();
            if (json === "[DONE]") break;

            try {
              const parsed = JSON.parse(json);
              const content = parsed?.choices?.[0]?.delta?.content || "";
              if (content) {
                botReply += content;

                // Update bot message in real-time
                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === botId ? { ...m, text: botReply } : m
                  )
                );
              }
            } catch (e) {
              console.error("Error parsing JSON:", e);
            }
          }
        }
      }
    } catch (error) {
      console.error("Error fetching AI response:", error);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === botId
            ? { ...m, text: "Error: Could not connect to LM Studio." }
            : m
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-gray-900 to-black relative overflow-hidden">
      {/* Grid pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:64px_64px] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,black_40%,transparent_100%)]"></div>

      {/* Header */}
      <div className="px-6 py-4 pl-72 bg-black border-b border-gray-800 shadow-lg relative z-10">
        <h1 className="text-xl font-bold bg-gradient-to-r from-white to-[#22e03e] bg-clip-text text-transparent">
          CleverBotX Chat
        </h1>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6 pb-32 relative z-10">
        <div className="max-w-7xl mx-auto">
          {messages.map((msg) => (
            <ChatMessage key={msg.id} sender={msg.sender} text={msg.text} />
          ))}

          {isLoading && (
            <div className="flex justify-start mb-4">
              <div className="text-gray-400 text-sm italic">Thinking...</div>
            </div>
          )}
        </div>
      </div>

      {/* Input */}
      <div className="relative z-10 m-10 ">
        <ChatInput onSend={handleSend} />
      </div>
    </div>
  );
};

export default ChatPage;