"use client";
import React from "react";
import BlurText from "@/components/BlurText";
import TextType from "../TextType";
import GradientText from "../GradientText";
import { useRouter } from "next/navigation";

interface HeroProps {
  onAnimationComplete?: () => void;
}

const Hero: React.FC<HeroProps> = ({ onAnimationComplete }) => {
  const router = useRouter();
  
  const handler = () => {
     router.push("/chat");
  }

  return (
    <section className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-gray-900 to-black px-4 relative overflow-hidden">
      {/* Grid pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:64px_64px] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,black_40%,transparent_100%)]"></div>

      <div className="text-center max-w-4xl mx-auto relative z-10">
        {/* Title */}
        <div className="mb-8">
          <GradientText
            colors={["#ffffff", "#22e03e", "#22e03e"]} // white to light gray gradient
            animationSpeed={3}
            showBorder={false}
            className="text-6xl md:text-7xl lg:text-8xl font-bold  leading-tight drop-shadow-lg "
          >
            CleverBotX
          </GradientText>
        </div>

        {/* Main Heading */}
        <BlurText
          text="Your Smart AI Chat Companion"
          delay={150}
          animateBy="words"
          direction="top"
          className="text-3xl md:text-5xl lg:text-6xl font-bold text-white mb-8 leading-tight drop-shadow-lg"
        />

       

        {/* Subheading */}
        <div className="mb-12">
          <TextType
            text={[
              "Ask questions and get instant answers.",
              "Explore interactive AI conversations.",
              "Your AI, your way.",
            ]}
            typingSpeed={75}
            pauseDuration={1500}
            showCursor={true}
            cursorCharacter="__"
            className="text-xl md:text-2xl text-gray-300 font-light leading-relaxed"
          />
        </div>
      </div>

      {/* CTA Button */}
      <div className="relative z-10 mt-8">
        <button onClick={handler} className="rounded-full bg-gradient-to-r from-white to-[#22e03e] text-black py-3 px-8 text-lg font-semibold flex items-center space-x-2 transition-all duration-300 transform hover:scale-105 hover:shadow-lg">
          <span>Start Chatting</span>
        </button>
      </div>
    </section>
  );
};

export default Hero;
