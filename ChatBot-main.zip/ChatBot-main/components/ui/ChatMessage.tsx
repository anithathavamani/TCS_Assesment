import React from "react";
import ReactMarkdown from "react-markdown";

type Props = {
  sender: "user" | "bot";
  text: string;
};

const ChatMessage: React.FC<Props> = ({ sender, text }) => {
  const isUser = sender === "user";

  return (
    <div className={`flex px-4 ${isUser ? "justify-end" : "justify-start"}`}>
      {isUser ? (
        <div className="p-[1px] rounded-xl rounded-bl-none bg-gradient-to-r from-white via-white via-40% to-[#22e03e] max-w-[75%] shadow-md">
          <div className="prose whitespace-pre-wrap bg-gray-900 text-white p-2 rounded-[14px]">
            <ReactMarkdown>{text}</ReactMarkdown>
          </div>
        </div>
      ) : (
        <div className="p-[3px] rounded-xl rounded-bl-none bg-gradient-to-r from-white via-white via-40% to-[#22e03e] max-w-[75%] shadow-md">
          <div className="prose whitespace-pre-wrap bg-gray-900 text-white px-6 py-3 rounded-[14px]">
            <ReactMarkdown>{text}</ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatMessage;
