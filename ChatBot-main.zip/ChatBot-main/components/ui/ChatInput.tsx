import React, { useState } from "react";

interface ChatInputProps {
  onSend: (message: string) => void;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSend }) => {
  const [text, setText] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = text.trim();
    if (!trimmed) return;
    onSend(trimmed);
    setText("");
  };

  return (
    <div className="w-full flex justify-center items-center text-center">
      <form
        onSubmit={handleSubmit}
        className="fixed bottom-20 w-full max-w-[1300px] h-20 bg-gray-900 px-4 py-3 flex items-center border border-gray-800 rounded-md shadow-lg z-50 mx-auto left-1/2 transform -translate-x-1/2"
      >
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type your message..."
          className="flex-1 bg-gray-300 h-10 text-black placeholder-gray-800 px-4 py-2 rounded-md focus:outline-none focus:bg-gradient-to-r from-white via-white via-40% to-[#22e03e]"
        />

        <button
          type="submit"
          className="ml-4 bg-[#22e03e] text-black font-medium px-4 py-2 rounded-md hover:opacity-90 transition"
        >
          Send
        </button>
      </form>
    </div>
  );
};

export default ChatInput;
